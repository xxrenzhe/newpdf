import { ToolbarItemBase } from '../ToolbarItemBase';

class Mouse extends ToolbarItemBase {
    init() {
        this.name = 'mouse';
    }
}

export default Mouse;